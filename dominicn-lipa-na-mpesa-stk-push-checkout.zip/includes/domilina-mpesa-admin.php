<?php
defined( 'ABSPATH' ) || exit;

// ---------------------------------------------------------------------------
// Free helper: returns extra CSS for the analytics dashboard.
// Kept outside the class so wp_add_inline_style() can reference it simply.
// ---------------------------------------------------------------------------

function domilina_mpesa_analytics_inline_css() {
	return '
.domilina-kpi-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; margin-bottom:28px; }
@media (max-width:768px){ .domilina-kpi-grid{ grid-template-columns:1fr; } }
';
}

// ---------------------------------------------------------------------------
// Inline helper: transaction query utilities (formerly a standalone class)
// ---------------------------------------------------------------------------

/**
 * DOMILINA_Mpesa_Tx_Queries
 *
 * Lightweight query helper embedded within the admin file.
 * Handles all reads from the custom transactions table.
 */
class DOMILINA_Mpesa_Tx_Queries {

	private $tbl;

	public function __construct() {
		global $wpdb;
		// $this->tbl = $wpdb->prefix . 'domilina_mpesa_transactions';
		$this->tbl = esc_sql( $wpdb->prefix . 'domilina_mpesa_transactions' );
	}
	public function summary() {
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		$revenue    = (float) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(amount) FROM {$this->tbl} WHERE status = %s", 'completed' ) );
		$total      = (int)   $wpdb->get_var( "SELECT COUNT(*) FROM {$this->tbl}" );
		$successful = (int)   $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->tbl} WHERE status = %s", 'completed' ) );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter

		$rate = $total > 0 ? round( ( $successful / $total ) * 100, 1 ) : 0;

		return compact( 'revenue', 'total', 'successful', 'rate' );
	}

	public function chart_series() {
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(date_created) AS d, COUNT(*) AS cnt, SUM(CASE WHEN status=%s THEN amount ELSE 0 END) AS rev FROM {$this->tbl} WHERE date_created >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(date_created) ORDER BY d ASC",
				'completed'
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	public function list_rows( $limit = 20, $offset = 0 ) {
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$this->tbl} ORDER BY date_created DESC LIMIT %d OFFSET %d",
				$limit,
				$offset
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter
	}

	public function row_count() {
		global $wpdb;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, PluginCheck.Security.DirectDB.UnescapedDBParameter -- table name is safe, built from $wpdb->prefix
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->tbl}" );
	}
}

// ---------------------------------------------------------------------------
// Admin panel
// ---------------------------------------------------------------------------

/**
 * DOMILINA_Mpesa_Admin_Panel
 *
 * Registers the plugin's admin menu pages and renders both the
 * Tailwind-based analytics dashboard and the settings guide.
 */
class DOMILINA_Mpesa_Admin_Panel {

	/** @var string Hook suffix for main page. */
	private $menu_hook   = false;
	/** @var string Hook suffix for settings sub-page. */
	private $config_hook = false;

	/** @var DOMILINA_Mpesa_Tx_Queries */
	private $queries;

	public function __construct() {
		$this->queries = new DOMILINA_Mpesa_Tx_Queries();

		add_action( 'admin_menu',    [ $this, 'register_pages' ] );
		add_action( 'admin_notices', [ $this, 'mail_disabled_notice' ] );
	}

	// -----------------------------------------------------------------------
	// Menu registration
	// -----------------------------------------------------------------------

	public function register_pages() {
		$nonce = wp_create_nonce( 'domilina_mpesa_admin_view' );

		$this->menu_hook = add_menu_page(
			__( 'M-Pesa Analytics', 'dominicn-lipa-na-mpesa-stk-push-checkout' ),
			__( 'Lipa na Mpesa', 'dominicn-lipa-na-mpesa-stk-push-checkout' ),
			'manage_options',
			'domilina_mpesa_main',
			[ $this, 'render_analytics' ],
			'dashicons-money-alt',
			54.5
		);

		// Note: We can't easily add nonces to the actual menu slug in add_menu_page
		// without breaking things, so we will use a hybrid approach in the renderers.

		$this->config_hook = add_submenu_page(
			'domilina_mpesa_main',
			__( 'Settings Guide', 'dominicn-lipa-na-mpesa-stk-push-checkout' ),
			__( 'Settings Guide', 'dominicn-lipa-na-mpesa-stk-push-checkout' ),
			'manage_options',
			'domilina_mpesa_settings',
			[ $this, 'render_config_guide' ]
		);

		add_action( 'admin_print_styles-' . $this->menu_hook,   [ $this, 'load_assets' ] );
		add_action( 'admin_print_styles-' . $this->config_hook, [ $this, 'load_assets' ] );
	}

	// -----------------------------------------------------------------------
	// Asset loading
	// -----------------------------------------------------------------------

	public function load_assets() {
		wp_enqueue_script( 'domilina_mpesa_chartjs',   DOMILINA_MPESA_PLUGIN_URL . 'assets/js/chart.min.js', [], '4.4.3', true );
		wp_enqueue_style(  'domilina_mpesa_jost',      'https://fonts.googleapis.com/css2?family=Jost:wght@400;500;600;700&display=swap', [], '1.0' );
		wp_enqueue_style(  'domilina_mpesa_admin_css', DOMILINA_MPESA_PLUGIN_URL . 'assets/css/admin-styles.css', [ 'dashicons', 'domilina_mpesa_jost' ], DOMILINA_MPESA_VERSION );
		wp_add_inline_style( 'domilina_mpesa_admin_css', wp_kses_post( domilina_mpesa_analytics_inline_css() ) );
	}

	/**
	 * Inline chart initialization script (called from render_analytics).
	 *
	 * @param array $dates Chart dates.
	 * @param array $revenues Chart revenue data.
	 */
	public function enqueue_chart_script( $dates, $revenues ) {
		wp_localize_script( 'domilina_mpesa_chartjs', 'domilinaParams', [
			'labels'   => $dates,
			'revenues' => $revenues,
		] );

		$inline_script = "
		document.addEventListener('DOMContentLoaded', function () {
			var ctx = document.getElementById('domilinaMpesaChart');
			if ( ! ctx ) { return; }
			new Chart(ctx.getContext('2d'), {
				type: 'line',
				data: {
					labels: domilinaParams.labels,
					datasets: [{
						label: 'Revenue (KES)',
						data: domilinaParams.revenues,
						backgroundColor: 'rgba(16,185,129,0.15)',
						borderColor: '#10b981',
						borderWidth: 2,
						tension: 0.3,
						fill: true,
						pointBackgroundColor: '#10b981'
					}]
				},
				options: {
					responsive: true,
					plugins: { legend: { display: false } },
					scales: { y: { beginAtZero: true } }
				}
			});
		});
		";

		wp_add_inline_script( 'domilina_mpesa_chartjs', $inline_script, 'after' );
	}

	// -----------------------------------------------------------------------
	// Notices
	// -----------------------------------------------------------------------

	public function mail_disabled_notice() {
		if ( function_exists( 'mail' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}

		$get_tab     = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_STRING );
		$get_section = filter_input( INPUT_GET, 'section', FILTER_SANITIZE_STRING );
		$on_wc_tab   = (
			'woocommerce_page_wc-settings' === $screen->id &&
			'checkout' === $get_tab &&
			( ! $get_section || 'domilina_mpesa_checkout' === $get_section )
		);

		$our_pages = [ $this->menu_hook, $this->config_hook ];

		// Nonce check for our internal pages only
		$get_nonce = filter_input( INPUT_GET, '_wpnonce', FILTER_SANITIZE_STRING );
		if ( in_array( $screen->id, $our_pages, true ) && $get_nonce ) {
			wp_verify_nonce( $get_nonce, 'domilina_mpesa_admin_view' );
		}

		if ( ! in_array( $screen->id, $our_pages, true ) && ! $on_wc_tab ) {
			return;
		}

		$search_url = esc_url( admin_url( 'plugin-install.php?s=smtp&tab=search&type=term' ) );
		printf(
			'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
			wp_kses_post( sprintf(
				/* translators: %s: Search URL for SMTP plugins */
				__( '<strong>Warning:</strong> The PHP <code>mail()</code> function is disabled. Install an <a href="%s" target="_blank">SMTP plugin</a> to ensure order emails are delivered.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ),
				$search_url
			) )
		);
	}

	// -----------------------------------------------------------------------
	// Analytics dashboard
	// -----------------------------------------------------------------------

	public function render_analytics() {
		$get_nonce = filter_input( INPUT_GET, '_wpnonce', FILTER_SANITIZE_STRING );
		if ( $get_nonce ) {
			wp_verify_nonce( $get_nonce, 'domilina_mpesa_admin_view' );
		}

		$kpi   = $this->queries->summary();
		$chart = $this->queries->chart_series();

		$get_paged = filter_input( INPUT_GET, 'paged', FILTER_SANITIZE_NUMBER_INT );
		$page      = max( 1, (int) ( $get_paged ? absint( $get_paged ) : 1 ) );
		$limit = 20;
		$rows  = $this->queries->list_rows( $limit, ( $page - 1 ) * $limit );
		$pages = (int) ceil( $this->queries->row_count() / $limit );

		$dates    = array_column( $chart, 'd' );
		$revenues = array_column( $chart, 'rev' );

		?>
		<div class="wrap domilina-admin-dashboard">
			<div class="domilina-analytics-wrap">
			<div class="domilina-analytics-inner">

				<!-- Header -->
				<div class="domilina-analytics-header">
					<div style="display:flex;align-items:center;">
						<img src="<?php echo esc_url( DOMILINA_MPESA_PLUGIN_URL . 'assets/img/mpesa-logo.png' ); ?>" alt="M-Pesa">
						<h1><?php esc_html_e( 'M-Pesa Analytics Dashboard', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h1>
					</div>
					<?php
					$settings_url = add_query_arg( [
					'_wpnonce' => wp_create_nonce( 'domilina_mpesa_admin_view' ),
				], admin_url( 'admin.php?page=domilina_mpesa_settings' ) );
					?>
					<a href="<?php echo esc_url( $settings_url ); ?>"><?php esc_html_e( 'Settings Guide', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></a>
				</div>

				<!-- KPI Cards -->
				<div class="domilina-kpi-grid">
					<div class="domilina-kpi-card green">
						<h3><?php esc_html_e( 'Total Revenue', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h3>
						<div class="domilina-kpi-value"><?php echo wp_kses_post( wc_price( $kpi['revenue'] ) ); ?></div>
						<p class="domilina-kpi-label"><?php esc_html_e( 'Lifetime M-Pesa Sales', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></p>
					</div>
					<div class="domilina-kpi-card blue">
						<h3><?php esc_html_e( 'Total Transactions', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h3>
						<div class="domilina-kpi-value"><?php echo esc_html( number_format_i18n( $kpi['total'] ) ); ?></div>
						<p class="domilina-kpi-label"><?php esc_html_e( 'Completed & Failed', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></p>
					</div>
					<div class="domilina-kpi-card purple">
						<h3><?php esc_html_e( 'Success Rate', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h3>
						<div class="domilina-kpi-value"><?php echo esc_html( $kpi['rate'] ); ?>%</div>
						<p class="domilina-kpi-label"><?php esc_html_e( 'Completion Rate', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></p>
					</div>
				</div>

				<!-- Chart -->
				<div class="domilina-chart-box">
					<h3><?php esc_html_e( 'Revenue — Last 30 Days', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h3>
					<canvas id="domilinaMpesaChart" height="100"></canvas>
				</div>

				<!-- Transactions table -->
				<div class="domilina-table-box">
					<div class="domilina-table-header">
						<h3><?php esc_html_e( 'Transaction Log', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h3>
					</div>
					<table class="domilina-tx-table">
						<thead>
							<tr>
								<?php foreach ( [ 'Date', 'Order', 'Phone', 'Amount', 'M-Pesa ID', 'Status' ] as $col ) : ?>
									<th><?php echo esc_html( $col ); ?></th>
								<?php endforeach; ?>
							</tr>
						</thead>
						<tbody>
							<?php if ( ! empty( $rows ) ) : ?>
								<?php foreach ( $rows as $t ) :
									if ( 'completed' === $t['status'] ) {
										$badge = 'domilina-status-completed';
									} elseif ( 'failed' === $t['status'] ) {
										$badge = 'domilina-status-failed';
									} elseif ( 'pending' === $t['status'] ) {
										$badge = 'domilina-status-pending';
									} else {
										$badge = 'domilina-status-default';
									}
								?>
								<tr>
									<td><?php echo esc_html( $t['date_created'] ); ?></td>
									<td><a href="<?php echo esc_url( admin_url( 'post.php?post=' . absint( $t['order_id'] ) . '&action=edit' ) ); ?>">#<?php echo absint( $t['order_id'] ); ?></a></td>
									<td><?php echo esc_html( $t['phone_number'] ); ?></td>
									<td><?php echo wp_kses_post( wc_price( $t['amount'] ) ); ?></td>
									<td class="mono"><?php echo esc_html( $t['transaction_id'] ? $t['transaction_id'] : '—' ); ?></td>
									<td><span class="domilina-badge <?php echo esc_attr( $badge ); ?>"><?php echo esc_html( ucfirst( $t['status'] ) ); ?></span></td>
								</tr>
								<?php endforeach; ?>
							<?php else : ?>
								<tr><td colspan="6" class="empty"><?php esc_html_e( 'No transactions yet.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></td></tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>

				<!-- Pagination -->
				<?php if ( $pages > 1 ) : ?>
				<div class="domilina-pagination">
					<?php for ( $i = 1; $i <= $pages; $i++ ) :
						$nav_url = add_query_arg( [
							'paged'    => $i,
							'_wpnonce' => wp_create_nonce( 'domilina_mpesa_admin_view' ),
						], admin_url( 'admin.php?page=domilina_mpesa_main' ) );
					?>
					<a href="<?php echo esc_url( $nav_url ); ?>"
					   class="<?php echo $i === $page ? 'current' : ''; ?>"><?php echo absint( $i ); ?></a>
					<?php endfor; ?>
				</div>
				<?php endif; ?>

			</div><!-- .domilina-analytics-inner -->
			</div><!-- .domilina-analytics-wrap -->
		</div>
		<?php
		$this->enqueue_chart_script( $dates, $revenues );
	}




	// -----------------------------------------------------------------------
	// Settings guide
	// -----------------------------------------------------------------------

	public function render_config_guide() {
		$get_nonce = filter_input( INPUT_GET, '_wpnonce', FILTER_SANITIZE_STRING );
		if ( $get_nonce ) {
			wp_verify_nonce( $get_nonce, 'domilina_mpesa_admin_view' );
		}
		$wc_url  = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=domilina_mpesa_checkout' );
		$dev_url = 'https://developer.safaricom.co.ke/user/me/apps';

		ob_start();
		?>
		<div class="domilina-settings-container-minimal">
			<div class="domilina-settings-header-minimal">
				<h2><?php esc_html_e( 'M-Pesa Configuration Guide', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></h2>
				<p><?php esc_html_e( 'Follow these steps to start accepting M-Pesa payments.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></p>
			</div>

			<?php
			$steps = [
				[ 'dashicons-admin-settings', 'Step 1: Go to M-Pesa Settings',
					/* translators: %s: WooCommerce M-Pesa settings URL */
					sprintf( __( 'Navigate to <a href="%s" target="_blank">WooCommerce → Payments → M-Pesa</a>.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ), esc_url( $wc_url ) ) ],
				[ 'dashicons-toggle-on', 'Step 2: Enable & Pick Environment',
					__( 'Tick "Enable M-Pesa Payment", then choose <strong>Sandbox</strong> for testing or <strong>Live</strong> for real payments.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ) ],
				[ 'dashicons-admin-network', 'Step 3: Enter API Credentials',
					/* translators: %s: Safaricom Developer Portal URL */
					sprintf( __( 'Copy your Consumer Key, Secret, Short Code and Passkey from the <a href="%s" target="_blank">Safaricom Developer Portal</a>.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ), esc_url( $dev_url ) ) ],
				[ 'dashicons-admin-links', 'Step 4: Confirm Callback URL',
					__( 'The callback URL is auto-generated. Your site must use HTTPS.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ) ],
				[ 'dashicons-saved', 'Step 5: Save and Test',
					__( 'Click "Save changes" then run a sandbox transaction to verify everything works.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ) ],
			];
			foreach ( $steps as [ $icon, $title, $body ] ) :
			?>
			<div class="domilina-settings-card-minimal">
				<h3><span class="dashicons <?php echo esc_attr( $icon ); ?>"></span> <?php echo esc_html( $title ); ?></h3>
				<p><?php echo wp_kses_post( $body ); ?></p>
			</div>
			<?php endforeach; ?>
		</div>
		<?php
		$content = ob_get_clean();
		$this->scaffold_page( __( 'Settings Guide', 'dominicn-lipa-na-mpesa-stk-push-checkout' ), $content, 'domilina-settings-page' );
	}

	// -----------------------------------------------------------------------
	// Shared page shell (for non-dashboard pages)
	// -----------------------------------------------------------------------

	private function scaffold_page( $title, $content, $extra_class = '' ) {
		ob_start();
		do_action( 'domilina_all_admin_notices' );
		$notices = ob_get_clean();
		?>
		<div class="wrap">
			<?php echo wp_kses_post( $notices ); // safe, already generated by WP actions ?>
			<div class="domilina-admin-wrap <?php echo esc_attr( $extra_class ); ?>">
				<div class="domilina-admin-header">
					<img src="<?php echo esc_url( DOMILINA_MPESA_PLUGIN_URL . 'assets/img/mpesa-logo.png' ); ?>" alt="M-Pesa Logo" class="domilina-header-logo">
					<h1><?php echo esc_html( $title ); ?></h1>
					<!-- <span class="domilina-version-tag"><?php esc_html_e( 'Free Version', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?></span> -->
				</div>
				<div class="domilina-admin-content">
					<?php echo wp_kses_post( $content ); ?>
				</div>
				<div class="domilina-admin-footer">
					<?php esc_html_e( 'Thank you for using M-Pesa Checkout.', 'dominicn-lipa-na-mpesa-stk-push-checkout' ); ?>
				</div>
			</div>
		</div>
		<?php
	}
}
